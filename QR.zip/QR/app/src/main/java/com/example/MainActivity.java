package com.example;
 
import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import java.io.UnsupportedEncodingException;

public class MainActivity extends Activity {
    private EditText editText;
    private ImageView generateButton;
    private ImageView qrCodeImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);
        generateButton = findViewById(R.id.generateButton);
        qrCodeImageView = findViewById(R.id.qrCodeImageView);

        generateButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					qrCodeImageView.setVisibility(View.VISIBLE);
					generateQRCode();
					
				}
			});
			
			
			
		editText.addTextChangedListener(new TextWatcher() { 
				@Override
				// when there is no text added 
				public void beforeTextChanged(CharSequence s, int start, int count, int after) { 
					if (s.toString().trim().length() == 0) { 
						generateButton.setVisibility(View.VISIBLE);
						
					} else { 
				
					} 
				} 

				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) { 
			

				} 
		
				@Override
				public void afterTextChanged(Editable s) { 
					if (s.toString().trim().length() == 0) { 
						generateButton.setVisibility(View.GONE);
						
					} 
				} 
			}); 




		
			
			
    }

    private void generateQRCode() {
		String text = editText.getText().toString();

		try {
			BitMatrix bitMatrix = new MultiFormatWriter().encode(new String(text.getBytes("UTF-8"), "ISO-8859-1"), BarcodeFormat.QR_CODE, 200, 200);
			int width = bitMatrix.getWidth();
			int height = bitMatrix.getHeight();
			Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
			for (int x = 0; x < width; x++) {
				for (int y = 0; y < height; y++) {
					int pixelColor = bitMatrix.get(x, y) ? android.graphics.Color.BLACK : android.graphics.Color.WHITE;
					bitmap.setPixel(x, y, pixelColor);
				}
			}
			qrCodeImageView.setImageBitmap(bitmap);
		} catch (WriterException | UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
	
}

